import { createAction } from '@ngrx/store';
import { Movie } from 'src/app/Models/movie';

export const getMovies = createAction('Loading the Movie From Backend');

export const getMoviesSuccess = createAction(
  'Movies Loaded....!',
  (movies: ReadonlyArray<Movie>) => ({ movies })
);

export const addMovie = createAction(
  'Adding Movie To BackEnd ',

  (movie: Movie) => ({ movie })
);

export const addMovieSuccess = createAction(
  'Added Movie To BackEnd ',

  (movie: Movie) => ({ movie })
);
