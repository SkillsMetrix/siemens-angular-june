import { Component, Input, OnInit } from '@angular/core';
import { Movie } from '../Models/movie';
import { DataService } from '../Service/data.service';
import { Store } from '@ngrx/store';
import { MovieState } from '../Store/Reducers/movie.reducers';

@Component({
  selector: 'app-movie-list',
  templateUrl: './movie-list.component.html',
  styleUrls: ['./movie-list.component.css'],
})
export class MovieListComponent implements OnInit {
 
  movieFromStore= this.store.select('movies')
  constructor(private store: Store<MovieState>) {}

  ngOnInit(): void {}
}
