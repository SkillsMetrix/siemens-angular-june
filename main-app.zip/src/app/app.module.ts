import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { MainAppComponent } from './components/main-app/main-app.component';
import { HeaderComponent } from './components/header/header.component';
import { FooterComponent } from './components/footer/footer.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CalcComponent } from './components/calc/calc.component';
import { FormComponent } from './components/form/form.component';
import { DdformComponent } from './components/ddform/ddform.component';
import { ErrorComponent } from './components/error/error.component'
import { HttpClientModule } from '@angular/common/http';
import { UserdetailsComponent } from './components/userdetails/userdetails.component'
@NgModule({
  // all components declared here
  declarations: [
    AppComponent,
    MainAppComponent,
    HeaderComponent,
    FooterComponent,
    CalcComponent,
    FormComponent,
    DdformComponent,
    ErrorComponent,
    UserdetailsComponent
  ],
  // declare module
  imports: [
    BrowserModule,
    FormsModule,
    AppRoutingModule,ReactiveFormsModule,HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
