import { Component } from '@angular/core';
import { UserDataService } from '../../shared/services/user-data.service';

@Component({
  selector: 'app-userdetails',
  templateUrl: './userdetails.component.html',
  styleUrl: './userdetails.component.css'
})
export class UserdetailsComponent {


  constructor(private us:UserDataService){
    this.loadUsers()
  }

   users:any[]=[]
     loadUsers(){
      this.us.loadUserFromDB().subscribe((res)=>{
         this.users=res
      })
     }
}
