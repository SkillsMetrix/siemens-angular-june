
export const FormErrorMessage:Record<string,string>={
    required: 'This Field is required',
    email:'Please Enter Valid Email'
}